extern void aecium(int, char **);

int main(int argc, char **argv)
{
	aecium(argc, argv);	

	return 0;
}
